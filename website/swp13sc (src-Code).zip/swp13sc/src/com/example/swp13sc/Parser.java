package com.example.swp13sc;
import java.io.*;
import java.util.*;
import java.util.regex.*;

import com.example.swp13sc.ChessDataModelToRDFConverter;
import com.example.swp13sc.ChessGame;
import com.example.swp13sc.ChessMove;
import com.example.swp13sc.ChessPlayer;
import com.example.swp13sc.ChessDataModelToRDFConverter.OutputFormats;
import com.example.swp13sc.ChessGame.Builder;


public class Parser {
	private String fileData;
	private FileInputStream fstream;
	String pgnFile;
	Pattern pattern;
	Matcher matcher;
	boolean inMoves;
	ChessGame chessGame;
	ChessMove chessMove;
	ChessPlayer whiteChessPlayer;
	ChessPlayer blackChessPlayer;
	ChessGame.Builder chessGameBuilder;
	ChessMove.Builder chessMoveBuilder;
	ChessPlayer.Builder chessPlayerBuilder;
	ChessDataModelToRDFConverter chessToRDF;
	FileOutputStream fStream;
	public Parser(String pgnFilePath, String outputFilePath)
	{
		pgnFile = pgnFilePath;
		chessToRDF = new ChessDataModelToRDFConverter();
		try
		{
		fStream = new FileOutputStream(outputFilePath,true);		
		}
		catch (Exception e)
		{
			System.err.println("Outputstrem error");
		}

	}
	///***************** NEW->
	public void addWhiteChessPlayer(String name)
	{
		chessPlayerBuilder = new ChessPlayer.Builder();
		chessPlayerBuilder.setName(name);
		chessPlayerBuilder.build();
		whiteChessPlayer = new ChessPlayer(chessPlayerBuilder);
		chessGameBuilder.setWhitePlayer(whiteChessPlayer);
		
	}
	public void addBlackChessPlayer(String name)
	{
		chessPlayerBuilder = new ChessPlayer.Builder();
		chessPlayerBuilder.setName(name);
		chessPlayerBuilder.build();
		blackChessPlayer = new ChessPlayer(chessPlayerBuilder);
		chessGameBuilder.setBlackPlayer(blackChessPlayer);
	}
	
	public void createChessGameBuilder()
	{
		chessGameBuilder = new ChessGame.Builder();
	}
	
	public void addMoveToGame(String move, int nr)
	{
		chessMoveBuilder = new ChessMove.Builder();
		chessMoveBuilder.setMove(move);
		chessMoveBuilder.setNr(nr);
		chessMoveBuilder.build();
		chessMove = new ChessMove(chessMoveBuilder);
		chessGameBuilder.addMove(chessMove);
	}
	
	public void addTagToGame(String tagName,String value)
	{
		if(tagName.equals("Event")){
			chessGameBuilder.setEvent(value);
		}
		else if(tagName.equals("Site")){
			chessGameBuilder.setSite(value);
		}
		else if(tagName.equals("Date")){
			chessGameBuilder.setDate(value);
		}
		else if(tagName.equals("Round" )){
			chessGameBuilder.setRound(value);
		}
		else if(tagName.equals("White")){
			addWhiteChessPlayer(value);
		}
		else if(tagName.equals("Black")){
			addBlackChessPlayer(value);			
		}
		else if(tagName.equals("Result")){
			chessGameBuilder.setResult(value);
		}
	}
	public void handleGame()
	{
		chessGameBuilder.build();
		chessGame = new ChessGame(chessGameBuilder);
		chessToRDF.convert(chessGame);
		chessToRDF.flushToStream(fStream, OutputFormats.TURTLE);
	}
	///****************************** <-NEW
	public boolean parseFile()
	{	
		try {
			fstream = new FileInputStream(pgnFile);
		} catch (FileNotFoundException e) {
			System.out.println("@Error: File not found!");
			e.printStackTrace();
			return false;
		}		
		inMoves = false;
		boolean inAttributes = true;
		DataInputStream in = new DataInputStream(fstream);
		BufferedReader br = new BufferedReader(new InputStreamReader(in));
		String strLine;
		String moveString = "";
		boolean inGame = false;
		int gameNumber = 0;
		try {
			while ((strLine = br.readLine()) != null)   {
				  // Print the content on the console
				if(strLine.startsWith("1"))
				{
					inMoves = true;
				}
				else if(strLine.startsWith("["))
				{
					if(!inGame)
					{
						gameNumber++;
						inGame = true;
						createChessGameBuilder();
						//System.out.println("GameNumber : " + gameNumber);
					}
					inAttributes = true;

				}
				else if(strLine.equals("")) {
				//	System.out.println("Read an empty Line.");
					if(inMoves)
					{
				//		System.out.println("inMoves");
						getMoves(moveString);
						moveString = "";
						handleGame();
						//System.out.println(chessGame.toString());
						inGame = false;
						inMoves = false;
					}
					else 
					{
				//		System.out.println("inAtt");
						inAttributes = false;	
					}
				}
				if(inMoves) {
					moveString += strLine;
				}		
				else if(inAttributes)
				{
					getAttributeAndValue(strLine);
					continue;
				}
			}
			if(inMoves)
			{
		//		System.out.println("inMoves");
				getMoves(moveString);
				moveString = "";
				handleGame();
				inMoves = false;
			}
			in.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}	
		return true;
	}
	
	public void getAttributeAndValue(String line)
	{
		String attribute = "";
		String value = "";
		try {
		int endOfAttribute = line.indexOf(" ");
		int valueBegin = line.indexOf("\"")+1;
		int valueEnd = line.lastIndexOf("\"");
		attribute = line.substring(1, endOfAttribute);
		value = line.substring(valueBegin,valueEnd);
		} catch (Exception e) {
			e.printStackTrace();
		}
		addTagToGame(attribute, value);
	}
	
	public void getMoves(String _moveString)
	{
		pattern = Pattern.compile("([a-zA-Z]{1,3}\\d)\\+?|" +
				"(\\d\\x2D\\d)|" +
				"(\\d\\x2D\\d\\x2D\\d)");
		String moveString = _moveString;
		List<String> movesList = new ArrayList<String>();
		//List<String> moveFromTo = new ArrayList<String>();

		int moveStart;
		int moveEnd;
		int moveFromEnd;
		int moveFromStart;
		int moveToStart;
		int moveToEnd;
		String result = "";
		String[] moves;
		//System.out.println(_moveString);

		matcher = pattern.matcher(moveString);
		boolean a = false;
		while(matcher.find())
		{
			movesList.add(matcher.group());
		}
		int i = 0;
		int counter = 1;
		for(int z = 0; z<movesList.size(); z+=2)
		{
			try{
			addMoveToGame(movesList.get(z)+ " " +movesList.get(z+1), counter);
			counter ++;
			}catch(Exception e)
			{
			}
			/*if(tmp.equals(movesList.get(movesList.size()-1)))
			{
				//if(i==1) //result
					//System.out.println();
				//System.out.println("Result : " + tmp);
			}
		    if(i==0 && !tmp.equals(movesList.get(movesList.size()-1)))
			{
			System.out.print(counter+": "+tmp);
			i++;
			}
			else if(i==1)
			{
				System.out.println(" -> "+tmp);
				counter++;
				i--;
			} */
		}
		//moveString = moveString.substring(2);
		
		/*	
		while(moveString.contains(" ")) {
			//moveFromTo = new ArrayList<String>();

			moveStart = moveString.indexOf(".")+1;	
			moveEnd = moveString.indexOf(".")-2;
			
			moveFromStart = moveString.indexOf(" ")-moveString.indexOf(".");
			moveFromEnd = moveString.indexOf(" ");
			moveFromTo.add(moveString.substring(moveFromStart, moveFromEnd));
			
			moveToStart = moveFromEnd + 1;
			moveToEnd = moveString.indexOf(arg0, arg1)); //////////EDDDDDDDDDIT
			moveFromTo.add(moveString.substring(moveToStart, moveToEnd));

			//movesList.add(moveFromTo);
			//moveFromTo.clear();
			//System.out.println(moveString);
			//moveString = moveString.substring(moveStart);						
		}
		*/
		//ERGEBNIS
		/*
		for(List tmp: movesList)
		{
			System.out.println(tmp.get(0) + "->" + tmp.get(1));
		}
		System.out.println(result); */
	}	
}
