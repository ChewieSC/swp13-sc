package com.example.swp13sc;


import java.io.File;
import javax.swing.JFileChooser;

import com.example.swp13sc.Parser;

import com.vaadin.server.VaadinRequest;
import com.vaadin.ui.Button;
import com.vaadin.ui.Button.ClickEvent;
import com.vaadin.ui.Label;
import com.vaadin.ui.UI;
import com.vaadin.ui.VerticalLayout;
import com.vaadin.ui.AbstractTextField.TextChangeEventMode;
import com.vaadin.ui.Button.ClickListener;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.HorizontalSplitPanel;
import com.vaadin.ui.TextArea;
import com.vaadin.ui.TextField;
import com.vaadin.ui.VerticalSplitPanel;
import javax.swing.filechooser.FileFilter;


/**
 * Main UI class
 */
@SuppressWarnings("serial")
public class Swp13scUI extends UI
{
	//---------------Game-Explorer Instanzen---------------//
	                       //TODO
	
	//---------------Suchfenster Instanzen-----------------//
	/**Layout fuer Suchfenster*/
	private VerticalLayout searchLayout = new VerticalLayout();
	/**Inneres Layout fuer Suchfenster*/
	private HorizontalLayout searchLayoutInner = new HorizontalLayout();
	
	/**Label mit Ueberschrift */
	private Label lblSearch = new Label("Suche nach Schachpartien");
	
    /**Button fur Suchfunktion*/    
    private Button btnSearch = new Button("Suche");
    
    /**neues Suchfeld*/
	private TextField tfSearch = new TextField();
	
	
	//--------------Konverterfenster Instazen-------------//
	/**Layout fuer Konverterfenster*/
	private VerticalLayout converterLayout = new VerticalLayout();
	/**Inneres KonverterFensterLayout*/
	private HorizontalLayout converterLayoutInner = new HorizontalLayout();
	/**Label Ueberschrift*/
	private Label lbConverter = new Label("Konvertierung PGN - RDF");
	/**Textfeld f�r pgn-upload*/
	private TextField tfToPars = new TextField();
	/**
	 * Textfeld F�r zu Parsende PGN 
	 */
	private TextArea taToPars = new TextArea();
	
	/**Button fur Konvertierung*/    
    private Button btnConvert = new Button("Konvertieren");
    /**Button zum Suchen von Uploads*/
    private Button btnBrowse = new Button("Durchsuchen");
    
    /**
     * OutputLabel
     */
    private Label lblOut = new Label();
    /**
     * AnzeigeLabel
     */
    private Label lblInfo = new Label();

//------------------------------Seitenaufbau-------------------------------------//
	/**
	 * Methode wird zum erstellen der GUI und ihrer Komponenten aufgerufen
	 * -konstruiert die Seite
	 */
	@Override
	protected void init(VaadinRequest request) {
		
		initSearch();
		initConverter();
		initLayout();
		initButtons();
	}
//------------------------------Methodenteil--------------------------//	
	
/**
 * Methode erstellt das Layout der Website	
 */
    private void initLayout()
     {
       
      //Hauptfenster 	2geteilt
	  HorizontalSplitPanel splitPanel = new HorizontalSplitPanel();
      setContent(splitPanel);
      
      //Rechts, Unterfenster 2geteilt
      VerticalSplitPanel splitPanelInner = new VerticalSplitPanel();
      splitPanel.addComponent(splitPanelInner);
            
      splitPanelInner.addComponent(searchLayout); 
      splitPanelInner.addComponent(converterLayout);
      
      //--------------Aufbau Suchfenster---------------//      
      searchLayout.addComponent(lblSearch);
      searchLayout.addComponent(searchLayoutInner);
      
      // searchLayout.addComponent(lblSearch);
      searchLayoutInner.addComponent(tfSearch);
      searchLayoutInner.addComponent(btnSearch);
      
      
      
      //--------------Aufbau Konverterfenster---------------//
      converterLayout.addComponent(lbConverter);
      converterLayout.addComponent(converterLayoutInner);
      converterLayoutInner.addComponent(tfToPars);
      converterLayoutInner.addComponent(btnBrowse);
      converterLayout.addComponent(taToPars);
      converterLayout.addComponent(btnConvert);
      
      converterLayout.addComponent(lblOut);
      converterLayout.addComponent(lblInfo);
      
      //-------------Eigenschaften der GUIkomponenten----------//
        
      //Anpassen Searchfenster
      searchLayout.setMargin(true);
      searchLayout.setVisible(true);
      
      searchLayoutInner.setSizeFull();
      searchLayoutInner.setWidth("100%");
           
      tfSearch.setWidth("100%");
      taToPars.setWidth("100%");
      
      searchLayoutInner.setExpandRatio(tfSearch, 1);
      
      
//      searchLayoutInner.setMargin(true);
//      searchLayoutInner.setVisible(true);
      
      //Anpassen Konverterfenster
      converterLayoutInner.setSizeFull();
      converterLayoutInner.setWidth("100%");
      converterLayout.setWidth("100%");
      
      tfToPars.setWidth("100%");
      taToPars.setWidth("100%");
      
      converterLayoutInner.setExpandRatio(tfToPars, 1);
      converterLayout.setExpandRatio(taToPars, 1);
      
      converterLayout.setMargin(true);
      converterLayout.setVisible(true);
      
//      converterLayoutInner.setMargin(true);
//      converterLayoutInner.setVisible(true);  
   
      
     }
		
/**
 * Methode baut das Suchfeld und seine Funktion auf	
 */
  private void initSearch()
       {
		 
	     tfSearch.setInputPrompt("Suchbegriff");
	     tfSearch.setTextChangeEventMode(TextChangeEventMode.LAZY);     

	   }
  
  
 /**
  * Methode initialiesiert Buttons und ihre Listener 
  * bzw. funktionalit�ten
  */
  private void initButtons()
  {
	  
  //------------------Buttons Konverterfenster-------------------//
	  
     // Innere Klasse initialisiert Buttonlistener  
	 btnBrowse.addClickListener(new ClickListener(){
	 public void buttonClick(ClickEvent event)
	 {
		JFileChooser fc = new JFileChooser();
		fc.setFileFilter( new FileFilter()
		   {
		    @Override public boolean accept( File f )
		       {
		         return f.isDirectory() ||
		         f.getName().toLowerCase().endsWith( ".pgn" );
		       }
		    @Override public String getDescription()
		          {
		            return "*.pgn ( Portable Game Notation)";
		          }
	        });
		     
		int state = fc.showOpenDialog( null );
		if ( state == JFileChooser.APPROVE_OPTION )
	        {
		      File file = fc.getSelectedFile();
		          
		      tfToPars.setValue(file.getPath());
		      System.out.println( file.getPath() );
		    }
		      else System.out.println( "Auswahl abgebrochen" );
		     
		    }	 
	 });
	 
	
	 // Innere Klasse initialisiert Konverterbutton und seinen Listener stellt	
	 btnConvert.addClickListener(new ClickListener(){
	 public void buttonClick(ClickEvent event) {
		 
		 JFileChooser fs = new JFileChooser();
		  fs.setDialogTitle("Datei speichern");
		  fs.setDialogType(JFileChooser.SAVE_DIALOG);
		  fs.addChoosableFileFilter(new FileFilter() {
         
	     public boolean accept(File f) 
	     {
            if (f.isDirectory()) return true;
            
            return f.getName().toLowerCase().endsWith(".rdf");
         }

         public String getDescription()
          {
             return "rdf-File (*.rdf)";
          }
           
		  });
              int state = fs.showSaveDialog(null);
              
      		  if ( state == JFileChooser.APPROVE_OPTION )
      	        {
      		      File file = fs.getSelectedFile();
      		          
      		      lblOut.setValue("Output: " + file.getPath());
      		      System.out.println( file.getPath() );
      		    }
      		      else System.out.println( "Auswahl abgebrochen" );
		      
        
		 
//		 if (taToPars.getValue().equals(""))
//			 postPgn(tfToPars.getValue());
//		 if (tfToPars.getValue().equals(""))
		  
			 postPgn(tfToPars.getValue(),lblOut.getValue());
			 
//		// System.out.println("lala");
//	     if (taToPars.getValue().equals(new String(""))) {
//	    	 System.out.println("lala");
////		    		System.out.println("Textfield"); 
////		    		 System.out.println(tfToPars.getValue());
////		    		 postPgn(tfToPars.getValue());
//		 		   
//		 
//		//wenn im textfeld was steht dann...    		
//		if (tfToPars.getValue().equals(new String("")) != true)
//			   {
////		    		
////		    postPgn(tfToPars.getValue());
////		    System.out.println(tfToPars.getValue());
//			
//			//if (postPgn(tfToPars.getValue())) System.out.println("erfolgreich gesendet");
//		    			
//		       }
//		       else {  // vaadin eigene fenster nutzen ....
//		    		   System.out.println("steht in beiden nix drin"); 		    			
//		    	    }
//		    	
//		    	}
//		    	else { 
//		    	System.out.println("Textarea");
//		    	
//		    	
//    			if (postText(taToPars.getValue()))
//    		    	System.out.println("erfolgreich gesendet"); 
//		     			    	
//		    	}
			    }
		 });
	 //------------------Buttons Suchfenster-------------------// 
	 
	 
	 
	 
	 
	 
	 
  }
  
  //*------------------Anbindung der Komponenten an das Datenmodell------------//
  
  public boolean postPgn( String pathIn, String pathOut) {
	  
	  Parser p = new Parser(pathIn, pathOut);
		//Parser p = new Parser("D:\\swtProjekt\\current 2011.pgn");
	  lblInfo.setValue("Parsen...Konvertieren...");
	  
	  if(p.parseFile()) lblInfo.setValue("!PGN wurde erfolgreich Konvertiert!");
		else			lblInfo.setValue("Fehler beim Parsen/Konvertieren!");
	  
	return true;  
  }
  
  
  
public boolean postText( String text) {
	  
	Parser parser = new Parser(text, "test.txt" );
	  //Post text
	return true;  
  }
  
  
  
  
  
  
  /**
   * Methode baut Knverterfenster und dessen Funktionen auf
   */
  private void initConverter()
  {
	  
	 
  }
  
}