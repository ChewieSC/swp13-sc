//package com.example.swp13sc;
//
//import com.example.swp13sc.Parser;
//
//public class main {
//
//	/**
//	 * @param args
//	 */
//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//		Parser p = new Parser("D:\\swtProjekt\\testpgn.txt", "output_test.txt");
//		//Parser p = new Parser("D:\\swtProjekt\\current 2011.pgn");
//		if(p.parseFile())
//			System.out.println("Done.");
//		else
//			System.out.println("Error!");
//	}
//
//}
